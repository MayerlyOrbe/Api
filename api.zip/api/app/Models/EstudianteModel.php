<?php

namespace App\Models;

use CodeIgniter\Model;

class EstudianteModel extends Model
{
    protected $table      = 'estudiantes';
    protected $primaryKey = 'id_estudiantes';
    protected $allowedFields = ['id_estudiantes', 'nombre', 'apellido', 'cedula', 'correo', 'sexo'];
}


