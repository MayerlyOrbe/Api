<?php

namespace App\Controllers;

use App\Models\EstudianteModel;
use CodeIgniter\RESTful\ResourceController;

class Estudiantes extends ResourceController
{
    protected $modelName = 'App\Models\EstudianteModel';
    protected $format    = 'json';

    // Obtener todos los estudiantes
    public function index()
    {
        return $this->respond($this->model->findAll());
    }

    // Obtener un estudiante por ID
    public function show($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            return $this->respond($data);
        } else {
            return $this->failNotFound('Estudiante no encontrado');
        }
    }

    // Crear un nuevo estudiante
    public function create()
    {
        $data = [
            'id_estudiantes' => $this->request->getPost('id_estudiantes'),
            'nombre'         => $this->request->getPost('nombre'),
            'apellido'       => $this->request->getPost('apellido'),
            'cedula'         => $this->request->getPost('cedula'),
            'correo'         => $this->request->getPost('correo'),
            'sexo'           => $this->request->getPost('sexo')
        ];

        if ($this->model->insert($data)) {
            return $this->respondCreated($data);
        } else {
            return $this->failValidationErrors($this->model->validation->getErrors());
        }
    }

    // Actualizar un estudiante existente
    public function update($id = null)
    {
        $data = $this->request->getRawInput();
        if ($this->model->update($id, $data)) {
            return $this->respond($data);
        } else {
            return $this->failValidationErrors($this->model->validation->getErrors());
        }
    }

    // Eliminar un estudiante
    public function delete($id = null)
    {
        if ($this->model->delete($id)) {
            return $this->respondDeleted(['id' => $id]);
        } else {
            return $this->failNotFound('Estudiante no encontrado');
        }
    }
}
