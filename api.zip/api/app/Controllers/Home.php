<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        // Aquí puedes devolver un mensaje de bienvenida o información básica sobre tu API
        $data = [
            'message' => 'Bienvenido a la API de Estudiantes',
            'endpoints' => [
                'GET /estudiantes' => 'Obtener todos los estudiantes',
                'GET /estudiantes/{id}' => 'Obtener un estudiante por ID',
                'POST /estudiantes' => 'Crear un nuevo estudiante',
                'PUT /estudiantes/{id}' => 'Actualizar un estudiante existente',
                'DELETE /estudiantes/{id}' => 'Eliminar un estudiante'
            ]
        ];

        return $this->response->setJSON($data);
    }
}

