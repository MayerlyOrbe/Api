<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/jesmay', 'Home::index');
$routes->resource('estudiantes');
